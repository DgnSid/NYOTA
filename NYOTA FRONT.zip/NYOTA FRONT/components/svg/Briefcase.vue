<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.875 5.62524H3.125C2.77982 5.62524 2.5 5.90507 2.5 6.25024V16.2502C2.5 16.5954 2.77982 16.8752 3.125 16.8752H16.875C17.2202 16.8752 17.5 16.5954 17.5 16.2502V6.25024C17.5 5.90507 17.2202 5.62524 16.875 5.62524Z" stroke="url(#paint0_linear_2855_3574)" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.125 5.62524V4.37524C13.125 4.04372 12.9933 3.72578 12.7589 3.49136C12.5245 3.25694 12.2065 3.12524 11.875 3.12524H8.125C7.79348 3.12524 7.47554 3.25694 7.24112 3.49136C7.0067 3.72578 6.875 4.04372 6.875 4.37524V5.62524" stroke="url(#paint1_linear_2855_3574)" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M17.5 9.86743C15.2205 11.1857 12.6332 11.8784 10 11.8752C7.36629 11.8821 4.77803 11.1892 2.5 9.86743" stroke="url(#paint2_linear_2855_3574)" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9.0625 9.37524H10.9375" stroke="url(#paint3_linear_2855_3574)" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_2855_3574" x1="2.5" y1="16.8752" x2="18.5613" y2="7.42995" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint1_linear_2855_3574" x1="6.875" y1="5.62524" x2="10.9397" y2="1.14335" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint2_linear_2855_3574" x1="2.5" y1="11.8753" x2="4.32306" y2="5.86834" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint3_linear_2855_3574" x1="9.0625" y1="10.3752" x2="10.6671" y2="9.04827" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
</template>

<script>
    export default {
        name: 'Briefcase',
    };
</script>