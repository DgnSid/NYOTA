
<template>
    <svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13.0234 5.1394L7.16297 10.9999L13.0234 16.8603" stroke="url(#paint0_linear_1768_4988)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_1768_4988" x1="13.0234" y1="16.8603" x2="4.96984" y2="15.0843" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
  </template>
  
  <script>
  export default {
    name: 'SingleBack',
  };
  </script>