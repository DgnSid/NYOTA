
<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0.625 7.50024L10 2.50024L19.375 7.50024L10 12.5002L0.625 7.50024Z" stroke="url(#paint0_linear_2855_3567)" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M14.6875 18.7502V10.0002L10 7.50024" stroke="url(#paint1_linear_2855_3567)" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M17.1875 8.66431V12.9299C17.1869 13.0627 17.143 13.1916 17.0625 13.2971C16.5391 14.0002 14.3203 16.5627 10 16.5627C5.67969 16.5627 3.46094 14.0002 2.9375 13.2971C2.85695 13.1916 2.81306 13.0627 2.8125 12.9299V8.66431" stroke="url(#paint2_linear_2855_3567)" stroke-linecap="round" stroke-linejoin="round"/>
        <defs>
        <linearGradient id="paint0_linear_2855_3567" x1="0.625" y1="12.5002" x2="16.671" y2="-0.769512" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint1_linear_2855_3567" x1="10" y1="18.7502" x2="16.5343" y2="17.5494" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint2_linear_2855_3567" x1="2.8125" y1="16.5627" x2="15.4103" y2="6.45029" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        </defs>
    </svg>
</template>

<script>
    export default {
        name: 'GraduationCap',
    };
</script>
