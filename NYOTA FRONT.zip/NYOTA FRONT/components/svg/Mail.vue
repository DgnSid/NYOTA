<template>
    <svg width="32" height="33" viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M28 7.5L16 18.5L4 7.5" stroke="url(#paint0_linear_2376_8323)" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M4 7.5H28V24.5C28 24.7652 27.8946 25.0196 27.7071 25.2071C27.5196 25.3946 27.2652 25.5 27 25.5H5C4.73478 25.5 4.48043 25.3946 4.29289 25.2071C4.10536 25.0196 4 24.7652 4 24.5V7.5Z" stroke="url(#paint1_linear_2376_8323)" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M13.8125 16.5L4.3125 25.2125" stroke="url(#paint2_linear_2376_8323)" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M27.6875 25.2125L18.1875 16.5" stroke="url(#paint3_linear_2376_8323)" stroke-linecap="round" stroke-linejoin="round"/>
        <defs>
        <linearGradient id="paint0_linear_2376_8323" x1="4" y1="18.5" x2="21.9568" y2="1.22006" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint1_linear_2376_8323" x1="4" y1="25.5" x2="29.6981" y2="10.3875" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint2_linear_2376_8323" x1="4.3125" y1="25.2125" x2="15.431" y2="19.8654" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint3_linear_2376_8323" x1="18.1875" y1="25.2125" x2="29.306" y2="19.8654" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        </defs>
    </svg>
</template>

<script>
    export default {
        name: 'Mail',
    };
</script>