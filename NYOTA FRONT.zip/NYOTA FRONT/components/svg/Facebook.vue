
<template>    
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M18.54 10.6568H20.0007V8.11263C19.7487 8.07796 18.882 8 17.8728 8C13.2513 8 14.5086 13.2334 14.3247 14H12V16.8441H14.3241V24H17.1733V16.8447H19.4033L19.7573 14.0007H17.1727C17.298 12.118 16.6654 10.6568 18.54 10.6568Z" fill="white"/>
    </svg>

</template>
  
<script>
export default {
  name: 'Facebook',
};
</script>