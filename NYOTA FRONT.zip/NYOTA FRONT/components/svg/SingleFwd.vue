<template>
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8.65039 5.1394L14.5109 10.9999L8.65039 16.8603" stroke="url(#paint0_linear_1768_4987)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_1768_4987" x1="8.65039" y1="16.8603" x2="16.704" y2="15.0843" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
  </template>
  
  <script>
  export default {
    name: 'SingleFwd',
  };
  </script>