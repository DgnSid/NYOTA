<template>
    <svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M17.1 1H1.7C1.3134 1 1 1.3134 1 1.7V14.3C1 14.6866 1.3134 15 1.7 15H17.1C17.4866 15 17.8 14.6866 17.8 14.3V1.7C17.8 1.3134 17.4866 1 17.1 1Z" stroke="url(#paint0_linear_2961_6930)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M1 11.5L5.40125 7.09872C5.46638 7.03258 5.54402 6.98006 5.62965 6.94421C5.71527 6.90836 5.80717 6.88989 5.9 6.88989C5.99283 6.88989 6.08473 6.90836 6.17035 6.94421C6.25598 6.98006 6.33361 7.03258 6.39875 7.09872L10.3012 11.0012C10.3664 11.0674 10.444 11.1199 10.5296 11.1557C10.6153 11.1916 10.7072 11.2101 10.8 11.2101C10.8928 11.2101 10.9847 11.1916 11.0704 11.1557C11.156 11.1199 11.2336 11.0674 11.2987 11.0012L13.1012 9.19872C13.1664 9.13258 13.244 9.08006 13.3296 9.04421C13.4153 9.00836 13.5072 8.98989 13.6 8.98989C13.6928 8.98989 13.7847 9.00836 13.8703 9.04421C13.956 9.08006 14.0336 9.13258 14.0987 9.19872L17.8 12.9" stroke="url(#paint1_linear_2961_6930)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M11.8508 6.6C12.4307 6.6 12.9008 6.1299 12.9008 5.55C12.9008 4.9701 12.4307 4.5 11.8508 4.5C11.2709 4.5 10.8008 4.9701 10.8008 5.55C10.8008 6.1299 11.2709 6.6 11.8508 6.6Z" fill="url(#paint2_linear_2961_6930)"/>
        <defs>
        <linearGradient id="paint0_linear_2961_6930" x1="1" y1="15" x2="19.912" y2="4.99044" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint1_linear_2961_6930" x1="1" y1="12.9" x2="10.607" y2="1.05562" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        <linearGradient id="paint2_linear_2961_6930" x1="10.8008" y1="6.6" x2="13.3342" y2="5.48263" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7A00"/>
        <stop offset="0.645833" stop-color="#FB9B11"/>
        </linearGradient>
        </defs>
    </svg>
</template>

<script>
    export default {
        name: 'IconPicture',
    };
</script>


    