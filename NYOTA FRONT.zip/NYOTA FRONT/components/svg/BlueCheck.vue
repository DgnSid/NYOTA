<template>
    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect y="0.000366211" width="20.8372" height="20.8372" rx="10.4186" fill="#1D67F1"/>
    <path d="M5 10.2261L8.58738 14.193L15 7.00037" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</template>

<script>
    export default {
        name: 'BlueCheck',
    };
</script>    