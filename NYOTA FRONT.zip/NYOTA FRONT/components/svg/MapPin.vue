<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 10.6252C11.3807 10.6252 12.5 9.50596 12.5 8.12524C12.5 6.74453 11.3807 5.62524 10 5.62524C8.61929 5.62524 7.5 6.74453 7.5 8.12524C7.5 9.50596 8.61929 10.6252 10 10.6252Z" stroke="url(#paint0_linear_2855_3582)" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16.25 8.12524C16.25 13.7502 10 18.1252 10 18.1252C10 18.1252 3.75 13.7502 3.75 8.12524C3.75 6.46764 4.40848 4.87793 5.58058 3.70583C6.75269 2.53372 8.3424 1.87524 10 1.87524C11.6576 1.87524 13.2473 2.53372 14.4194 3.70583C15.5915 4.87793 16.25 6.46764 16.25 8.12524V8.12524Z" stroke="url(#paint1_linear_2855_3582)" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_2855_3582" x1="7.5" y1="10.6252" x2="13.5319" y2="7.96483" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint1_linear_2855_3582" x1="3.75" y1="18.1252" x2="19.9038" y2="12.6447" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
</template>

<script>
    export default {
        name: 'MapPin',
    };
</script>

    