<template>    
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M25 7L7 25" stroke="#fb9b11" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M25 25L7 7" stroke="#fb9b11" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_2057_8213" x1="7" y1="25" x2="28.7148" y2="15.4225" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint1_linear_2057_8213" x1="7" y1="25" x2="28.7148" y2="15.4225" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
</template>

<script>
    export default {
        name: 'Close',
    };
</script>