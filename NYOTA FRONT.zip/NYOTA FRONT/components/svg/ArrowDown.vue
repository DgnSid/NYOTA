<template>
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9.375 4.5L6 7.875L2.625 4.5" stroke="#fb9b11" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_2639_5751" x1="2.625" y1="4.5" x2="3.64782" y2="9.13801" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
</template>

<script>
    export default {
        name: 'ArrowDown',
    };
</script>
