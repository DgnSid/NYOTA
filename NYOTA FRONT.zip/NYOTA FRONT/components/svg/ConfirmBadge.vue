
<template>
    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle r="27.5" transform="matrix(-1 0 0 1 28 28)" fill="url(#paint0_linear_1773_5070)" stroke="url(#paint1_linear_1773_5070)"/>
    <path d="M23 28.2257L26.5874 32.1926L33 25" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_1773_5070" x1="8.34465e-07" y1="56" x2="67.5572" y2="26.2033" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    <linearGradient id="paint1_linear_1773_5070" x1="8.34465e-07" y1="56" x2="67.5572" y2="26.2033" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>    
</template>

<script>
export default {
  name: 'ConfirmBadge',
};
</script>
