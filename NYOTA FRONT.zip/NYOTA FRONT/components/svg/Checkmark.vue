<template>
    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5 10.2257L8.58738 14.1926L15 7" stroke="url(#paint0_linear_2920_7536)" stroke-linecap="round" stroke-linejoin="round"/>
    <defs>
    <linearGradient id="paint0_linear_2920_7536" x1="15" y1="7" x2="12.0125" y2="16.4172" gradientUnits="userSpaceOnUse">
    <stop stop-color="#FF7A00"/>
    <stop offset="0.645833" stop-color="#FB9B11"/>
    </linearGradient>
    </defs>
    </svg>
</template>

<script>
    export default {
        name: 'Checkmark',
    };
</script>