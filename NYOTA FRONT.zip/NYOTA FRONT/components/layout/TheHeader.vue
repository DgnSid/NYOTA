<!-----
*
Template
*
------>
<template>
    <header class="header" ref="header">
        <div class="container">            
            <div class="header__inner">
                <nuxt-link class="a-stagger-element__header" :to="'/' + currentLang">
                    <img class="header__inner__logo" src="/logo-nyota.svg" alt="Nyota logo" />
                </nuxt-link>
                <div class="header__inner__menu">
                    <nuxt-link :to="$t('menu.about_url')" class="header__inner__menu__element a-stagger-element__header">{{$t('menu.about_title')}}</nuxt-link>
                    <nuxt-link :to="$t('menu.talent_url')" class="header__inner__menu__element a-stagger-element__header">{{$t('menu.talent_title')}}</nuxt-link>
                    <nuxt-link :to="$t('menu.company_url')" class="header__inner__menu__element a-stagger-element__header">{{$t('menu.company_title')}}</nuxt-link>
                    <nuxt-link :to="$t('menu.contact_url')" class="header__inner__menu__element a-stagger-element__header">{{$t('menu.contact_title')}}</nuxt-link>
                    <nuxt-link :to="$t('menu.news_url')" class="header__inner__menu__element a-stagger-element__header">{{$t('menu.news_title')}}</nuxt-link>
                    <div v-if="this.$auth.loggedIn" class="header__inner__menu__element --orange">
                        <nuxt-link v-if="currentUser.user_type == 'Talent'" :to="$t('menu.profile_talent_url') + currentUser.user_id" class="a-stagger-element__header">{{$t('menu.profile_title')}}</nuxt-link>
                        <nuxt-link v-else :to="$t('menu.profile_company_url') + user_id" class="a-stagger-element__header">{{$t('menu.profile_title')}}</nuxt-link>
                        <span class="mx-xs a-stagger-element__header">|</span>
                        <span @click="logOut" :to="$t('menu.disconnect_url')" class="a-stagger-element__header">{{$t('menu.disconnect_title')}}</span>
                    </div>
                    <div v-else class="header__inner__menu__element --orange">
                        <span class="a-stagger-element__header" @click="openPopup">
                            <span>{{$t('menu.register_title')}}</span>
                            <arrow-down />
                        </span>
                        <span class="mx-xs a-stagger-element__header">|</span>
                        <nuxt-link :to="$t('menu.login_url')" class="a-stagger-element__header">{{$t('menu.login_title')}}</nuxt-link>
                    </div>
                    <nuxt-link
                        class="header__inner__menu__element a-stagger-element__header"
                        v-for="locale in availableLocales"
                        :key="locale.code"
                        :to="switchLocalePath(locale.code)">
                        
                        <span>{{ locale.code }}</span>
                        <arrow-down />
                    </nuxt-link>
                </div>
                <the-burger  class="header__inner__burger" />
            </div>
        </div>
        <popup-register />
    </header>
</template>

<!-----
*
Script
*
------>
<script>
    import { gsap } from "gsap";
    import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
    import { eventHub } from '@/plugins/eventhub'

    if (process.client) {
        gsap.registerPlugin(ScrollTrigger);
    }

    import popupRegister from '@/components/popup/popupRegister';
    import ArrowDown from '@/components/svg/ArrowDown';

    export default {
        components: { ArrowDown, popupRegister },
        beforeMount () {
            window.addEventListener('scroll', this.handleScroll);
        },
        beforeDestroy () {
            window.removeEventListener('scroll', this.handleScroll);
        },
        data: function () {
            return {
                isPopupActive: false,
                active: false,
            }
        },
        mounted: function () {
            setTimeout(() => {
                this.user_id = this.$auth.user ? this.$auth.user.id : ''
                this.user_type = this.$auth.user ? this.$auth.user['@type'] : ''
            }, 100)

            if(window.scrollY) {
                this.$refs.header.classList.value = this.$refs.header.classList.value + ' active'
            }

            const gsap = this.$gsap;
            this.tl = new gsap.timeline({
                scrollTrigger: {
                    trigger: ".header",
                }
            })

            this.tl.set('.a-stagger-element__header', {autoAlpha: 0, y:30})
            this.tl.staggerTo('.a-stagger-element__header', 0.6, {autoAlpha: 1, y:0, ease: "Power1.easeOut"}, .15, "=0.4")

            eventHub.$on('close-popup', (data) => {
                this.isPopupActive = data
            })

        },
        methods: {
            handleScroll(e) {
                if(window.scrollY && !this.active) {
                    this.$refs.header.classList.value = this.$refs.header.classList.value + ' active'
                    this.active = true
                } else if(!window.scrollY) {
                    this.$refs.header.classList.remove('active')
                    this.active = false
                }
            },

            logOut() {
                this.$auth.logout()
                this.$auth.$storage.removeUniversal('user')
                this.$router.push(`${this.currentLang}/login`)
            },

            openPopup() {
                eventHub.$emit('open-popup', true)
            },
        },
        computed: {
            availableLocales () {
                return this.$i18n.locales.filter(i => i.code !== this.$i18n.locale)
            },
            currentLang () {
                return this.$i18n.locale == 'en' ? this.$i18n.locale : ''
            },
            currentUser () {
                const user_id = this.$auth.user ? this.$auth.user.id : ''
                const user_type = this.$auth.user ? this.$auth.user['@type'] : ''

                return {user_id, user_type}
            }
        }
    };
</script> 

<!-----
*
Style scoped
*
------>
<style lang="scss" scoped>

    .header {
        position: fixed;

        top: 0;
        left: 0;

        z-index: 9;

        width: 100%;

        padding: 15px 0;

        background-color: transparent;

        transition: background-color .2s ease-out;

        &.active {
            background-color: $white;
        }
    }

    .header__inner {
        display: flex;
        align-items: center;
        justify-content: space-between;

        .header__inner__logo {
            @include media-breakpoint-down(md) {
                height: 40px;
            }
        }

        .header__inner__menu {
            display: flex;
            align-items: center;
            color: $black;

            @include media-breakpoint-down(md) {
                display: none;
            }

            .header__inner__menu__element {
                display: flex;
                align-items: center;
                color: $black;
                text-transform: uppercase;
                letter-spacing: 2px;
                font-size: 0.75rem;

                &:hover {
                    color: $orange;
                }

                &:not(:last-child) {
                    padding-right: 48px;
                }

                svg {
                    margin-bottom: 2px;
                }

                &.--orange {
                    a {
                        font-weight: 700;
                        color: $orange;
                        display: flex;
                        align-items: center;
                    }

                    span {
                        font-weight: 700;
                        cursor: pointer;
                        color: $orange;
                    }
                }

                @media  screen and (max-width: 1400px) {
                    letter-spacing: 1px;
                    &:not(:last-child) {
                        padding-right: 24px;
                    }
                }

                @media  screen and (max-width: 1100px) {
                    letter-spacing: 1px;

                    &:not(:last-child) {
                        padding-right: 20px;
                    }
                }
            }
        }

        .header__inner__burger {
            display: none;

            @include media-breakpoint-down(md) {
                display: flex;
                flex-direction: column;
                align-items: center;
                filter: invert(1);
            }
        }
    }

</style>