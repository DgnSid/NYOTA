<template>
    <div class="layout-contact">
        <TheHeaderSmall
            :title="$t('legalnoticepage.title')"
            :logo="true"
        />
        <div class="container">
            <div class="row">
                <div class="offset-lg-1">
                    <p class="mt-lg mb-lg">
                        <strong>Raison sociale :</strong> NYOTA<br>
                        <strong>Forme juridique</strong> SAS<br>
                        <strong>Capital social :</strong> 60 000 euros<br>
                        <strong>SIREN :</strong> 914494422<br>
                        <strong>Responsable :</strong> Yves Mariko
                    </p>


                    <p>
                        Conformément à la loi n°2004-575 du 21 juin 2004 pour la confiance dans l’économie numérique, nous vous informons que le site internet nyota.co est la propriété de NYOTA.
                    </p>
                    <p>
                        Le site internet nyota.co est hébergé sur les matériels informatiques de la société COGNIX SYSTEMS dont le siège social est : 50 rue Paul Langevin, 35200 RENNES.
                    </p>
                    <p>
                        Le site nyota.co est régi par le droit français ; les visiteurs ayant accès au site de l’étranger, doivent s'assurer du respect des lois localement applicables.
                    </p>
                    <p class="mb-lg">
                        Les mentions légales pouvant être modifiées à tout moment et sans préavis, nous vous engageons à les consulter régulièrement.
                    </p>

                    <h2>
                        Propriété intellectuelle
                    </h2>
                    <p>
                        NYOTA détient, se réserve et conserve tous les droits de propriété, notamment intellectuelle, y compris les droits de reproduction sur le présent site et les éléments qu’il contient. En conséquence et notamment toute reproduction partielle ou totale du présent site et des éléments qu’il contient est strictement interdite sans autorisation écrite de NYOTA.
                    </p>
                    <p class="mb-lg">
                        Les logos et tous autres signes distinctifs contenus sur ce site sont la propriété de NYOTA ou font l'objet d'une autorisation d'utilisation. Aucun droit ou licence ne saurait être attribué sur l'un quelconque de ces éléments sans l'autorisation écrite de NYOTA ou du tiers détenteur des droits.
                    </p>

                    <h2>
                        Exclusion de garantie et de responsabilité 
                    </h2>
                    <p>
                        L'utilisateur du site web nyota.co reconnaît avoir pris connaissance des présentes conditions d'utilisation du site et s'engage à les respecter.
                    </p>
                    <p>
                        NYOTA ne saurait être tenue pour responsable des dommages directs ou indirects qui pourraient résulter de l'accès au site ou de l'utilisation du site et/ou de ces informations, y compris l'inaccessibilité, les pertes de données, détériorations, destructions ou virus qui pourraient affecter l'équipement informatique de l'utilisateur et/ou de la présence de virus sur son site.
                    </p>
                    <p class="mb-lg">
                        Bien que NYOTA s'efforce de fournir un contenu fiable sur son site, il ne garantit pas que son contenu soit exempt d'inexactitudes ou d'omissions et ne saurait être tenu pour responsable des erreurs ou omissions, d'une absence de disponibilité des informations et des services. NYOTA se réserve à tout moment et sans préavis le droit d'apporter des améliorations et/ou des modifications au contenu de son site. En conséquence, l'utilisateur reconnaît se servir de ses informations sous sa responsabilité exclusive.
                    </p>

                    <h2>
                        Vie privée - Protection des données personnelles
                    </h2>
                    <p>
                        NYOTA a désigné un Délégué à la Protection des Données (DPO) afin de préserver votre vie privée et la protection de vos données personnelles dans le respect de la réglementation en vigueur. Le rôle du DRPO, est défini par le Règlement Général à la Protection des Données complétant les dispositions de la loi informatique et libertés du 06/01/1978 modifiée et son décret d'application du 20/10/2005.
                    </p>
                    <p>
                        Concernant les informations à caractère nominatif que vous seriez amenés à nous communiquer, vous bénéficiez d’un droit d’accès, de modification, de rectification et/ou de suppression conformément à la loi relative à la protection des personnes physiques à l’égard des traitements de données à caractère personnel n°2004-801 du 6 août 2004. Pour exercer ce droit veuillez adresser un message à :
                    </p>
                    <p>
                        NYOTA<br>
                        229, rue Saint-Honoré<br>
                        75001 Paris
                    </p>
                    <p>
                        Vos données peuvent être localisées en France, dans un pays de l’Union Européenne mais aussi potentiellement en dehors de l’Union Européenne. Dans ce dernier cas, nous nous assurons que les données qui se situent dans un pays hors UE assure un niveau de protection adéquat concernant le traitement des données en conformité avec la Règlementation sur la protection des Données. A défaut, nous prenons des mesures techniques appropriées de manière que le niveau de garanti par la Règlementation sur la protection des données soit respecté.
                    </p>
                    <p>
                        Les informations collectées font l'objet d'un traitement informatisé. Chaque internaute dispose d'un droit d'accès, de modification, de rectification et de suppression des données qui le concernent. (Art. 34 de la loi "Informatique et Libertés"). Ce droit peut être exercé auprès de : <a href="mailto:contact@nyota.co">contact@nyota.co</a>. Chaque utilisateur peut également adresser à NYOTA des directives relatives au sort de ses données après son décès.
                    </p>
                    <p class="mb-lg">
                        Les données à caractère personnel collectées sur ce site sont conservées au maximum jusqu’à l’expiration des délais de prescription légaux.
                    </p>

                    <h2>
                        Cookies, TAGS et traceurs
                    </h2>
                    <p>
                        Lors de la navigation sur notre site internet, des informations relatives à votre navigation peuvent être enregistrées dans votre terminal (ordinateur, tablette, smartphone ...) au travers de fichiers appelés "Cookies". 
                    </p>
                    <p>
                        Les cookies nous permettent notamment de réaliser un suivi de la fréquentation de notre site Internet.
                    </p>
                    <p>
                        Vous pouvez modifier vos préférences en matière de cookies en paramétrant votre navigateur :
                    </p>
                    <ul class="mb-lg">
                        <li>
                            <a href="http://docs.info.apple.com/article.html?path=Safari/3.0/fr/9277.html">Safari</a>
                        </li>
                        <li>
                            <a href="https://support.google.com/chrome/answer/95647?hl=fr&hlrm=en">Chrome</a>
                        </li>
                        <li>
                            <a href="https://support.mozilla.org/fr/kb/protection-renforcee-contre-pistage-firefox-ordinateur?redirectslug=Activer+et+d%C3%A9sactiver+les+cookies&redirectlocale=fr">Firefox</a>
                        </li>
                        <li>
                            <a href="https://support.microsoft.com/fr-fr/windows/supprimer-et-g%C3%A9rer-les-cookies-168dab11-0753-043d-7c16-ede5947fc64d">Internet Explorer</a>
                        </li>
                        <li>
                            <a href="https://support.apple.com/fr-fr/HT201265">iOS</a>
                        </li>
                    </ul>

                    <h2>
                        Liens vers d'autres sites
                    </h2>
                    <p>
                        Le site peut inclure des liens vers d'autres sites ou d'autres sources Internet. Dans la mesure où NYOTA ne peut contrôler ces sites et ces sources externes, NYOTA ne peut être tenu pour responsable de la mise à disposition de ces sites et sources externes, et décline ainsi toute responsabilité quant aux contenus, publicités, produits, services ou tout autre matériel disponible sur ou à partir de ces sites ou sources externes.
                    </p>
                    <p>
                        Ces liens sont proposés aux utilisateurs du site NYOTA en tant que service. La décision d'activer les liens vous appartient exclusivement. Nous vous rappelons que les sites non-affiliés sont soumis à leurs propres conditions d'utilisation.
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import TheHeaderSmall from '@/components/header/TheHeaderSmall.vue'

export default {
    name: "LegalNoticePage",
    components: {
        TheHeaderSmall,
    },
}
</script>

<style lang="scss" scoped>
    h2 {
        font-family: $font-family-custom;
        margin-bottom: 20px;
        color: $orange;
    }
    p {
        margin-bottom: 10px;
        color: $black;
        &.mb-lg {
            margin-bottom: 40px;
        }

        &.mt-lg {
            margin-bottom: 40px;
        }
    }

    a {
        color: $orange;
        text-decoration: underline;
    }

    ul {
        &.mb-lg {
            margin-bottom: 40px;
        }
    }
</style>
