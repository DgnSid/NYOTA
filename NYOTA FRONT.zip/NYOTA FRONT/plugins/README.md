# PLUGINS

This directory contains Javascript plugins that you want to run before mounting the root Vue.js application.
